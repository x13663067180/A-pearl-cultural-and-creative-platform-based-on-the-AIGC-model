<?php  
session_start(); // 初始化session

// 退出登录  
function logout()   
{  
    // 清除session中的用户信息
    unset($_SESSION['username']);  
    session_destroy(); // 销毁session
    
    // 清除cookie
    if (isset($_COOKIE['user_login'])) {  
        setcookie("user_login", '', time() - 3600); // 设置cookie过期
    }  
    if(isset($_COOKIE['user_level'])){
        setcookie("user_level", '', time() - 3600); // 设置cookie过期
    }
    // 获取referrer参数
    $referrer = isset($_GET['referrer']) ? $_GET['referrer'] : 'index.html';
    // 使用header函数重定向到referrer页面
    header('Location: ' . $referrer);
}  

// 调用注销函数
logout();
?>