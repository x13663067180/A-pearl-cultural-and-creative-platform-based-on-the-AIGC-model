<?php
// ... 与 manage.php 类似的 session 和连接设置 ...
header("Content-Type: text/html; charset=utf-8");

// 数据库连接信息
$host = 'localhost';
$user = 'root';
$password = 'root';
$dbname = 'firstime';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
$id = $_POST['id'];

// 首先，从数据库获取图片的路径
$stmt = $conn->prepare("SELECT path FROM image WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->store_result();

if($stmt->num_rows == 1) {
    $stmt->bind_result($path);
    $stmt->fetch();
    $stmt->close();

    // 检查文件是否存在，并删除
    if(file_exists($path)) {
        if(!unlink($path)) {
            // 如果文件无法删除，发送错误响应
            $response["success"] = false;
            $response["error"] = "文件删除失败。";
            header('Content-Type: application/json');
            echo json_encode($response);
            exit();
        }
    }

    // 文件已删除或不存在，现在删除数据库记录
    $stmt = $conn->prepare("DELETE FROM image WHERE id = ?");
    $stmt->bind_param("i", $id);

    if($stmt->execute()) {
        $response["success"] = true;
    } else {
        $response["success"] = false;
        $response["error"] = "数据库记录删除失败。";
    }
} else {
    $response["success"] = false;
    $response["error"] = "找不到指定的记录。";
}

$stmt->close();
$conn->close();

// 返回 JSON 响应
header('Content-Type: application/json');
echo json_encode($response);
?>