var inputText = document.getElementById(text)
inputText.innerText = "123"
