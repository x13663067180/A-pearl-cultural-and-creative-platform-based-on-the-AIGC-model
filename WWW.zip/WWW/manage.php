<?php
// 开启会话
session_start();

header("Content-Type: text/html; charset=utf-8");

// 数据库连接信息
$host = 'localhost';
$user = 'root';
$password = 'root';
$dbname = 'firstime';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

$userLevel = $_POST['userLevel'];
$username = $_POST['username']; // 从POST获取用户名

if ($userLevel == "1") {
    // 管理员，显示所有图片
    $sql = "select * from image";
} 
else {
    // 一般用户，仅显示当前用户的图片
    $sql = "SELECT * from image where username = '$username'";
}

$result = $conn->query($sql);
$html .= "<table>";
$html .= "<tr><th>ID</th><th>用户名</th><th>你的评价</th><th>操作</th></tr>"; // 确保只有这四个标题

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $html .= "<tr>";
        $html .= "<td>" . $row["id"] . "</td>";
        $html .= "<td>" . $row["username"] . "</td>";
        $html .= "<td id='like-status-" . $row["id"] . "'>" . $row["like"] . "</td>"; // “你的评价”内容的 ID
        $html .= "<td>" .
                 "<button onclick='viewImage(\"" . $row["path"] . "\")'>查看</button>".
                 "<button onclick='deleteImage(" . $row["id"] . ")'>删除</button>" .
                 "<button onclick='likeImage(" . $row["id"] . ")'>喜欢</button>" . // “喜欢”按钮
                 "<button onclick='dislikeImage(" . $row["id"] . ")'>不喜欢</button>" . // “不喜欢”按钮
                 "</td>";
        $html .= "</tr>";
    }
} else {
    $html .= "<tr><td colspan='4'>没有历史数据</td></tr>"; // 合并列数调整为4
}

$html .= "</table>";

echo $html;

$conn->close();
?>