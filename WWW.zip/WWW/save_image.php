<?php
// 假设您已经有了连接数据库的代码
header ( "Content-type:text/html;charset=utf-8" );
$db = mysqli_connect('localhost','root','root','firstime') or die('数据库连接失败');
$db->set_charset('utf8');

// 获取JSON数据
$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'];
$imgData = $data['imgData'];

// 将base64图片数据转换为图片文件
$imgData = str_replace('data:image/png;base64,', '', $imgData);
$imgData = str_replace(' ', '+', $imgData);
$imgData = base64_decode($imgData);

// 创建保存图片的文件夹
$savePath = "D:/phpstudy_pro/WWW/save/$username/";
if (!file_exists($savePath)) {
    mkdir($savePath, 0777, true);
}

// 创建唯一的图片文件名
$fileName = uniqid() . '.png';
$filePath = $savePath . $fileName;

// 保存图片到服务器
file_put_contents($filePath, $imgData);

// 将图片信息保存到数据库
$sql = "INSERT INTO image(id,path,username,`like`) 
            VALUES (null,'{$filePath}','{$username}','N')";

mysqli_query($db,$sql) or die(mysqli_error($db));

?>
