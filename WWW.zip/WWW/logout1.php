<?php  
session_start(); // 初始化session

// 退出登录  
function logout()   
{  
    // 清除session中的用户信息
    unset($_SESSION['username']);  
    session_destroy(); // 销毁session
    
    // 清除cookie
    if (isset($_COOKIE['user_login'])) {  
        setcookie("user_login", '', time() - 3600); // 设置cookie过期
    }
    if(isset($_COOKIE['user_level'])){
        setcookie("user_level", '', time() - 3600); // 设置cookie过期
    }
    // 重定向到登录页面或首页
    header('Location: right-sidebar.html'); // 根据实际情况修改重定向位置
}  

// 调用注销函数
logout();
?> 