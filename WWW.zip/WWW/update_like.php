<?php
// ... existing session and connection setup ...

$id = $_POST['id'];
$like = $_POST['like'];
// 创建数据库连接
$conn = mysqli_connect('localhost', 'root', 'root', 'firstime') or die('服务器连接失败');

// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
// Prepare and bind
$stmt = $conn->prepare("UPDATE image SET `like` = ? WHERE id = ?");
$stmt->bind_param("si", $like, $id);

$response = array();
if ($stmt->execute()) {
    $response["success"] = true;
} else {
    $response["success"] = false;
    $response["error"] = $conn->error;
}

$stmt->close();
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>