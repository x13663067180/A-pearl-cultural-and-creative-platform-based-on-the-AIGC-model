<?php

session_start(); // 开始session
header("Content-Type:text/html;charset=utf-8");

$conn = mysqli_connect('localhost', 'root', 'root', 'firstime') or die('服务器连接失败');
$conn->query("SET NAMES 'UTF8'");

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "select id, phone, username, password, level from 用户 where username = '$username' and password = '$password'" or die('请您再次检查输入是否正确，系统没有在注册用户中找到您');

$result = $conn->query($sql) or die('请您再次检测查输入是否正确，系统没有在注册用户中找到您');
if (!$result) {
    printf("发生错误: %s\n", mysqli_error($conn));
    exit();
}

$rows = $result->fetch_assoc();

if ($rows) {
    // 登录成功
    $_SESSION['username'] = $username; // 正确使用变量
    $_SESSION['level'] = $rows['level']; // 将用户level保存到session中
    setcookie('user_login', $username, time() + (15 * 60)); // 设置cookie 15分钟有效
    setcookie('user_level', $rows['level'], time() + (15 * 60)); // 设置cookie 15分钟有效
    // 检查referrer字段是否存在且不为空
    $referrer = (!empty($_POST['referrer']) and $_POST['referrer'] != 'register.html' )  ? $_POST['referrer'] : 'index.html';

    echo "登录成功!<a href='" . htmlspecialchars($referrer) . "'>若3秒后还未跳转，请点击这里</a>";
    echo "<script>setTimeout(function() { window.location.href = '" . htmlspecialchars($referrer) . "'; }, 3000);</script>";
} else {
    echo "认证失败，请重新认证！";
}

?>
