<?php    header ( "Content-type:text/html;charset=utf-8" );

    $conn = mysqli_connect('localhost','root','root','firstime') or die('数据库连接失败');

    $conn->set_charset('utf8');

 

    $username = $_POST['username'];

    $password = $_POST['password'];

    $phone = $_POST['phone'];

     

    $sql = "INSERT INTO 用户(id,username,phone,password) 

                VALUES (null,'{$username}' ,'{$phone}','{$password}')";

    mysqli_query($conn,$sql) or die(mysqli_error($conn));

    echo("注册成功<br/><a href='login.html'>点击返回登录</a>")     ?>